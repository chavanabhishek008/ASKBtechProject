import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View } from 'react-native';
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps';
import { TouchableOpacity } from 'react-native-gesture-handler';
import {FontAwesome5} from '@expo/vector-icons';
import { color } from 'react-native-reanimated';
const MapScreen =({navigation})=> {

    return (
     /*
        <View style={styles.header}>
              <TouchableOpacity style={{alignItems: "flex-end", marginTop: '5%',marginRight:'4%'}}
               onPress={navigation.toggleDrawer}
              >
                    <FontAwesome5 name="bars" size={28} color='white' />
                    <Text style={{fontWeight: 'bold',alignItems: 'center'}}>DASHBOARD</Text>
              </TouchableOpacity>

          
        
      </View>
      

const styles = StyleSheet.create({
  container:  {
    flex: 1,
    backgroundColor: "#fff",
},


    header: {
        flex:0.08,
        backgroundColor: '#2c4e54',
      }
})
*/
<MapView
style={{ flex: 0.92 }}
provider={PROVIDER_GOOGLE}
showsUserLocation
initialRegion={{
latitude: 18.52890,
longitude: 73.85085,
latitudeDelta: 0.0922,
longitudeDelta: 0.0421}}
 
/>
    );
  
  }
  
  export default MapScreen;