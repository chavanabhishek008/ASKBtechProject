import React, { Component } from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { IconButton, Colors } from 'react-native-paper';

var logo=require('../assets/plate1.png');
const HelpScreen =({navigation})=>{

    return (
      <View style={{ flex: 1,backgroundColor: '#fff'}}>
         <View style={styles.header}>
         <IconButton style={{alignItems: "flex-end", marginTop: '10%',marginLeft: '25%'}}
                icon="menu"
                color={Colors.white}
                size={30}
                onPress={navigation.toggleDrawer}
              />

          <Text style={{fontWeight: 'bold', fontSize: 25, color: 'white', alignSelf: 'center'}}>Help Me!</Text>

          </View>
          <View style={styles.footer}>

          <Image source={logo}
           style={{height:150,width:150,alignItems:'center',justifyContent:'center'}}>
           </Image>

           <Text style={{fontSize:20, marginLeft:'8%',alignItems: 'flex-start',color:'#2c4e54'}}>About Us!</Text>

           <Text style={{color:'#2c4e54',fontSize:18, marginLeft:'8%'}}>Mess Management System</Text>
          </View>
          
      </View>
    );
  }

export default HelpScreen;
const styles = StyleSheet.create({

  header: {
      height: '15%',
      backgroundColor: '#2c4e54',
      flexDirection: 'row-reverse'
    },
    footer: {
      flex: 1
    }
})