import React, {Component} from 'react';
import {Text, View, Image, StyleSheet, TouchableOpacity} from 'react-native';
import {FontAwesome5} from '@expo/vector-icons';
import { IconButton, Colors } from 'react-native-paper';

function meal({ navigation }) {
    return (

        <View style={styles.container}>

               

            <View style={styles.header}>
            <IconButton style={{alignItems: "flex-end", marginTop: '5%',marginRight: '32%',marginLeft: -5}}
                icon="arrow-left"
                color={Colors.white}
                size={30}
                onPress={()=>navigation.goBack()}
              />
                <Text style={{justifyContent: 'center',marginTop: 60, fontSize: 28, color: 'white'}}>Meal</Text>
            </View>

            <View style={styles.footer}>
                  <Image style={styles.image} source={require("../assets/plate1.png")} />

                <Text style={styles.text}>What do you want to have?</Text>
                <TouchableOpacity style={styles.loginBtn1}
                    onPress={() => navigation.navigate("lunch")}>
                    <Text style={styles.loginText1}>Lunch</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.loginBtn1}
                    onPress={() => navigation.navigate("dinner")}>
                    <Text style={styles.loginText1}>Dinner</Text>
                </TouchableOpacity>
            </View>
        </View>

    );

}
    
    

export default meal;

const styles= StyleSheet.create({
    container: {
        flex: 1
    },
    header: {
        height: '15%',
        backgroundColor: '#2c4e54',
        flexDirection: 'row'

    },
    image: {
        marginTop: 20,
        marginBottom: -40,
        marginLeft: '25%',
        justifyContent: 'center',
        width: 200,
        height: 200,
      },
    footer: {
        flex: 1,
        backgroundColor: 'white',
        borderRadius: 30
    },
    loginBtn1: {
        width: "70%",
        borderRadius: 25,
        height: 45,
        alignItems: "center",
        alignSelf: "center",
        justifyContent: "center",
        borderWidth: 1,
        marginTop: 10,
        borderColor: "#2c4e54",
      },
      loginText1: {
        color: "#2c4e54",
        alignSelf: "center",
        fontSize: 16,
        fontWeight: 'bold'
      },
      text: {
          fontSize: 20,
          padding:20,
         // marginLeft: '30%',
          //fontWeight: 'bold',
          color: '#2c4e54',
          alignSelf: 'center',
          marginBottom: 10
      }

});
