import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet,ImageBackground,Image, Text, View } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import {FontAwesome5} from '@expo/vector-icons';
import { IconButton, Colors } from 'react-native-paper';
import { StackRouter } from 'react-navigation';


var logo=require('../assets/plate2.png');
var bg=require('../assets/back2.png');
const dashboard = ({navigation,route}) =>{
  return(

    
      <ImageBackground source={bg} style={{height: '100%',flex: 1,width: '100%'}}>
          <View style={styles.header}>
              
          <IconButton style={{alignItems: "flex-end", marginTop: '5%',marginLeft: '30%'}}
                icon="menu"
                color={Colors.white}
                size={30}
                onPress={navigation.toggleDrawer}
              />

              <Text style={{justifyContent: 'center',marginTop: '5%',fontWeight: 'bold', fontSize: 25, color: 'white'}}>HOME</Text>
          </View>

          <View style={{ flex: 1, marginLeft: -20, marginTop: -10}}>
           
           <Image source={logo}
             style={{height:180,width:180}}>
           </Image>
           <Text style={{color: 'white',fontSize: 20,fontWeight:'bold', marginLeft:'10%',marginTop: -20}} >WELCOME!</Text>
           <Text style={{color: 'white',fontSize: 18, marginLeft:'10%',marginTop: -1}} >Sakshi Gujarathi</Text>
           <Text style={{color: 'white',fontSize: 14, marginLeft:'10%',marginTop: -1}} >111707015</Text>
           
          </View>

        <View style={styles.footer}>
        </View>
        <View style={styles.box1}>
            <View style={{height: '90%',marginTop: '10%', width: '45%',marginRight:'3%',padding:20,backgroundColor: '#244b51',borderRadius:10}}>
              < TouchableOpacity style={styles.innerbox}
               onPress={() => navigation.navigate("meal")}>
                  <FontAwesome5 name= 'utensils' size={28} color='white' />   
                  
              </TouchableOpacity>
              <Text style={styles.text}>Meal</Text>
            </View>

            <View style={{height: '90%',marginTop: '10%', width: '45%', marginLeft: '3%', padding:20,backgroundColor: '#244b51',borderRadius: 10}}>
              <TouchableOpacity style={styles.innerbox}
                onPress={() => navigation.navigate("snacks")}>
                <FontAwesome5 name= 'coffee' size={28} color='white' />  
                
              </TouchableOpacity >
              <Text style={styles.text}>Snacks</Text>
            </View>
          </View>

          <View style={styles.box2}>
            <View style={{height: '90%',marginTop: '25%', width: '45%',marginRight:'3%',padding:20,backgroundColor: '#244b51',borderRadius:10}}>
            < TouchableOpacity style={styles.innerbox}
                 onPress={() => navigation.navigate("PaymentHistory")}>
                 <FontAwesome5 name= 'th-list' size={32} color='white' />  
                 
              </TouchableOpacity>

              <Text style={{fontSize:18,alignSelf: 'center',color: 'white', justifyContent:'center',marginLeft: -5,marginTop: -45}}>Payment History</Text>
            </View>

            <View style={{height: '90%',marginTop: '25%', width: '45%', marginLeft: '3%', padding:20,backgroundColor: '#244b51',borderRadius:10}}>
           
            < TouchableOpacity style={styles.innerbox}
                   onPress={() => navigation.navigate("Bills")}>
               <FontAwesome5 name= 'file' size={32} color='white' />   
              </TouchableOpacity>
              <Text style={styles.text}>Bills</Text>
            </View>
 

          </View> 
          <Text style={{alignSelf:'center', justifyContent:'center', position: 'absolute', fontWeight: 'bold',bottom: 15, color:'#2c4e54'}}>Have it your way!</Text>

         
      </ImageBackground>
    
         





  );
};
export default dashboard;

const styles = StyleSheet.create({

header: {

  height: '10%',
  backgroundColor: '#1c3a40',
  flexDirection: 'row-reverse'
},
box1: {
  padding:20,
  flex:0.5,
  flexDirection: 'row',
  alignContent: 'space-between',
  alignItems: 'stretch',
  justifyContent: 'center',
 
},
box2: {
  marginTop: -100,
  padding:20,
  flex:0.5,
  flexDirection: 'row',
  alignContent: 'space-between',
  alignItems: 'stretch',
  justifyContent: 'center',
  marginBottom: '50%'
},
footer: {
  position: 'absolute',
  height: '59%',
  width: '95%',
  marginTop: '82%',
  marginBottom: 1,
  backgroundColor: '#e9ecec',
  borderRadius:30,
  padding: 20,
  marginLeft: '3%',
  marginRight: '3%',
  justifyContent: 'center',

  alignItems: 'stretch',
 
},
text: {
  fontSize:18,
  alignSelf: 'center',
  color: 'white',
  marginLeft: -8,
  marginTop: -45
},
innerbox: {
  height: '100%', 
  width: '100%',
  marginLeft:'40%',
  marginTop: '20%',
  shadowColor: 'rgba(0, 0, 0, 0.1)',
  shadowOpacity: 0.8,
  elevation: 6,
  shadowRadius: 20 ,
  shadowOffset : { width: 1, height: 13},
}
})
