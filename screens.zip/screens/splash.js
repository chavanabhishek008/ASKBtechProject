import React, { Component } from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
//import * as Font from 'expo-font';



var logo=require('../assets/platename.png');
export default class splash extends Component{
  constructor(props){
    super(props);
    setTimeout(()=>
    {
      this.props.navigation.navigate("Loginpage");
    },4000);
  }

  /*
  constructor(){
    super()
    this.state={
      fontLoaded:false
    }
  }

async componentDidMount(){
  await Font.loadAsync({
    'Chewy-Regular': require('./assets/fonts/Chewy-Regular.ttf')
  });
  this.setState({fontLoaded:true});
}
*/

 render()
 {
    return (
      <View style={{ flex: 1,backgroundColor: '#2c4e54',alignItems: 'center',justifyContent: 'center'}}>
           
           <Image source={logo}
           style={{height:250,width:250,alignItems:'center',justifyContent:'center',marginBottom:50}}>
           </Image>
           
           <Text style={{alignItems:'center', justifyContent:'center', position: 'absolute', bottom:8, color:'white'}}>Have it your way!</Text>
      </View>
    );
  }
}