import React, { useState } from 'react';
import { StyleSheet, Text, View, Image,TextInput, TouchableOpacity } from 'react-native';
import {Divider} from 'react-native-elements';
//import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { IconButton, Colors } from 'react-native-paper';

const ProfileScreen = ({navigation}) => {
    return(
     <View style={styles.container}>
         
         <View style={styles.header}>
           
         
              <IconButton style={{alignItems: "flex-end", marginTop: -45,marginLeft: '30%'}}
                icon="menu"
                color={Colors.white}
                size={30}
                onPress={navigation.toggleDrawer}
              />

     
            
       

        
         <Image style={styles.image} source={require("../assets/plate2.png")} />
         </View>

         <View>
         <Text style={styles.title}>HI, SAKSHI GUJARATHI!</Text>
         </View>
    
            <View style={styles.footer}>
                <View style={styles.inputView}>
                    <Text style={styles.textinput}>Mobile</Text>
                    <View style={styles.iconStyle}>
                        <AntDesign name= {"phone"} size={25} color='#666' />
                    </View>
                </View>
                <Divider />
                <View style={styles.inputView}>
                    <Text style={styles.textinput}>Email</Text>
                    <View style={styles.iconStyle}>
                        <AntDesign name= {"mail"} size={25} color='#666' />
                    </View>
                </View>
                <Divider />
                <View style={styles.inputView}>
                    <Text style={styles.textinput}>Password</Text>
                    <View style={styles.iconStyle}>
                        <AntDesign name= {"lock"} size={25} color='#666' />
                    </View>
                </View>
                <Divider />

                <TouchableOpacity onPress={() => console.log('Pressed')}>
                <View style={{marginTop:10,marginLeft:'85%', alignContent: 'flex-end'}}>
                        <AntDesign name= {"edit"} size={25} color='black' />
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style={styles.loginBtn1}>
                <Text style={styles.loginText1}>Sign Out</Text>
                
            </TouchableOpacity>
            

           
            </View>
    
      </View>
    );     
};

export default ProfileScreen;

const styles = StyleSheet.create({
    container: {
      flex: 1, 
      backgroundColor: '#2c4e54'
    },
    header: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row-reverse'
    },
    image: {
        marginTop: '12%',
        marginLeft: -10,
        marginRight: '10%',
        //flexDirection: 'column',
        //justifyContent: 'flex-start',
        width: 200,
        height: 200
      },
      titleview: {
        flexDirection: 'column',
        height: 35,
        marginLeft: '50%',
        alignSelf: 'center',
        justifyContent: 'flex-start',
        marginBottom: '10%'
      },
      title: {
        color: "#fff",
        marginLeft: 20,
        alignSelf: "flex-start",
        fontSize: 18
      },
    footer: {
        flex: 3,
        backgroundColor: '#fff',
       // borderTopLeftRadius: 30,
        //borderTopRightRadius: 30,
        //borderBottomLeftRadius: 30,
        //borderBottomRightRadius: 30,
        paddingVertical: 50,
        paddingHorizontal: 30
    },
    iconStyle: {
        padding: 5,
        marginTop: -40,
        marginRight: '84%',
        height: '100%',
        //justifyContent: '',
        alignItems: 'flex-start',
        //borderRightColor: '#ccc',
        //orderRightWidth: 1,
        width: 50,
    },

    textinput: {
        marginLeft: 60,
        height: 40,
        //flex: 1,
        fontSize: 20,
        padding: 5,
        color: "#666",
        alignContent: "flex-start",
        alignSelf: "flex-start",
    },
    loginBtn1: {
        width: "70%",
        borderRadius: 25,
        height: 45,
        alignItems: "center",
        alignSelf: "center",
        justifyContent: "center",
        borderWidth: 1,
        marginTop: 10,
        borderColor: "#2c4e54",
        position: 'absolute',
        bottom: '30%'
      },
      loginText1: {
        color: "#2c4e54",
       // alignItems: 'center',
        marginTop: 10,
        //marginBottom: -5,
        fontSize: 16,
        position: 'absolute',
        bottom: '30%'
      },
      inputView: {
       // borderWidth: 1,
        //borderRadius: 25,
        width: "100%",
        height: 45,
        //borderColor: "gray",
        marginBottom: 0,
        marginTop: 15,
        marginRight: '5%',
        alignItems: "center",
        alignSelf: "center",
      }
});