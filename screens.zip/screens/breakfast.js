import React from 'react';
import {Text, View, StyleSheet, TouchableOpacity, } from 'react-native';
import { FlatList } from 'react-native-gesture-handler';
import {Card} from 'react-native-paper';
import {FontAwesome5} from '@expo/vector-icons';
import { Button } from 'react-native';
//import {SimpleStepper} from 'react-native-simple-stepper';

//import Button1 from './Button1.js';
var array = [] ;
var array2 = [] ;
export default class snack extends React.Component{

    constructor(props){
        super(props);
        this.state={
            ItemList:[
                {ID: '1', Item: 'Samosa', Price: '10', Quantity: '1'},
                {ID: '2', Item: 'Pohe', Price: '10', Quantity: '1'},
                {ID: '3', Item: 'Milk', Price: '16', Quantity: '1'},
                {ID: '4', Item: 'Tea', Price: '8', Quantity: '1'},
                {ID: '5', Item: 'Tea', Price: '8', Quantity: '1'},
                {ID: '6', Item: 'Tea', Price: '8', Quantity: '1'},
                {ID: '7', Item: 'Tea', Price: '8', Quantity: '1'}
            ]
        }

           
    };

  
    ArrayFunction=(item, price)=>{

     
        array.push(item);
        array2.push(price);
        console.log(array);
     
      }

    render(){
        return(
            <View style={styles.container}>
                <View style={styles.header}>
                     <Text style={{justifyContent: 'center',marginLeft:'38%',marginTop: 30, fontSize: 25, color: 'white'}}>SNACKS</Text>
                     <FontAwesome5 name="angle-left" size={28} color='white' />
                </View>

                <View style={styles.footer}>
                <FlatList
                    data={this.state.ItemList}
                   // ItemSeparatorComponent={this.FlatListItemSeparator}
                    renderItem={({item})=>
                        <Card style={{marginTop:30, marginLeft: 10, borderRadius:20,width: '95%',flexDirection: 'row'}}>
                            <View style={styles.cardview}>
                                <Text style={{flex:1, fontSize:15}}>Item</Text>
                                <Text style={{flex:1}}>{item.Item}</Text>
                            </View>

                            <View style={styles.cardview}>
                                <Text style={{flex:1, fontSize:15}}>Price</Text>
                                <Text style={{flex:1}}>{item.Price}</Text>
                            </View>

                            <View  style={{width:50, marginLeft:'60%',marginRight:'10%',marginBottom: 10,marginTop: -10,justifyContent:'center', alignSelf: 'flex-end'}}
>
                                <Button
                                title="Add"
                                color="#2c4e54"
                                onPress={this.ArrayFunction.bind(this, item.Item, item.Price)}
                                />
                            </View>

                        </Card>
                    }
                keyExtractor={item=>item.Id}
                />
                <View>
                <TouchableOpacity style={styles.btn} onPress={() => this.props.navigation.navigate('order',{P1:array, P2:array2})}>
                   
                        <Text style={styles.btntext}>CONFIRM ORDER</Text>
                    </TouchableOpacity>
                </View>
           
  
                </View>

            </View>
        )
    }
}

const styles=StyleSheet.create({
    container: {
        flex:1
    },
    header:{
        flex: 0.1,
        backgroundColor: '#2c4e54'
    },
    btntext: {
        color: "black",
        width: "100%",
        alignSelf: "center",
        borderWidth: 1,
        alignContent: "center",
        justifyContent: "center",
        padding: 10,
        
        backgroundColor: "#fff",
    },

    footer: {
        flex: 0.9,
        backgroundColor: '#2c4e54',
      
    },
    cardview: {
        flex:2,
        padding: 3,
        borderRadius: 30,
        marginTop: 10,
        marginRight: 0,
        marginLeft: 10,
        backgroundColor: 'white',
        flexDirection: 'row'

    },

    btn: {
        alignSelf: "center",
        alignContent: "center",
        justifyContent: "center",
        height: 40,
        width: "95%",
        marginBottom: 8,
        marginTop: 10,
    },
    stepperContainer: {
        backgroundColor: 'transparent',
        flexDirection: 'row',
        width: 95,
        marginLeft: 230,
        borderWidth: 2,
        marginBottom: 10,
        borderRadius: 8,
        overflow: 'hidden',
        alignItems: 'center',
        borderColor: '#ccc',
      },
      stepperButton: {
        height: 15,
        width: 15,
      },
      stepperText: {
        paddingLeft: 10,
        paddingRight: 10,
        fontSize: 15,
        fontWeight: 'bold',
        color: '#333',
      },
})