import React, {Component} from 'react';
import {Text, View, Image, StyleSheet, TouchableOpacity} from 'react-native';
import {FontAwesome5} from '@expo/vector-icons';
import { Divider } from 'react-native-elements';
import { IconButton, Colors } from 'react-native-paper';

function Bills({ navigation }) {
    return (

        <View style={styles.container}>
            <View style={styles.header}>

            <IconButton style={{alignItems: "flex-end", marginTop: '5%',marginRight: '32%',marginLeft: -5}}
                icon="arrow-left"
                color={Colors.white}
                size={30}
                onPress={()=>navigation.goBack()}
              />
                <Text style={{justifyContent: 'center',marginTop: '20%', fontSize: 28, color: 'white'}}>Bills</Text>
            </View>

            <View style={styles.footer}>
                <Text style={{fontSize:18, color: '#2c4e54',marginTop: 20, marginLeft:15}}>Your expense for this month is</Text>

                <Text style={{fontSize:15, color: '#2c4e54',marginTop: 2, marginLeft:10,padding:10}}>Rs.3450</Text>

                <Divider />

                <Text style={{fontSize:18, color: '#2c4e54',marginTop: 10, marginLeft:20}}>Know your,</Text>
                
                <TouchableOpacity style={styles.loginBtn1}
                    >
                    <Text style={styles.loginText1}>Number of Meals</Text>
                </TouchableOpacity>

                
                <TouchableOpacity style={styles.loginBtn1}
                    onPress={() => navigation.navigate("coupon")}>
                    <Text style={styles.loginText1}>Coupons</Text>
                </TouchableOpacity>

            </View>
        </View>

    );

}
    
    

export default Bills;

const styles= StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column'
    },
    header: {
        minHeight: '15%',
        backgroundColor: '#2c4e54',
        flexDirection: 'row'

    },
    footer: {
        flex:1,
        backgroundColor: 'white',
        borderRadius: 30
    },
    loginBtn1: {
        width: "70%",
        borderRadius: 25,
        height: 45,
        marginLeft:15,
        padding:20,
        borderWidth: 1,
        marginTop: 10,
        borderColor: "#2c4e54",
      },
      loginText1: {
        color: "#2c4e54",
       
        justifyContent: 'center',
        marginTop:-10,
        fontSize: 16,
      }

});
