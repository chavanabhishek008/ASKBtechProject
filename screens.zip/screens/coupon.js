import React, { Component } from 'react';
import { StyleSheet, Text, View, Image } from 'react-native';
import { FlatList } from 'react-native-gesture-handler';
import {Card} from 'react-native-paper';
import { IconButton, Colors } from 'react-native-paper';

export default class coupon extends Component{

    constructor(props){
        super(props);
        this.state={
            DateList:[
                {ID: '1', Date: '1', Items: 'Coffee', Quantity: '1',Type: 'Evening', Price: '16'},
                {ID: '2', Date: '2', Items: 'Sandwich', Quantity: '1',Type: 'Morning', Price: '15'},
                {ID: '3', Date: '3', Items: 'Coffee', Quantity: '1',Type: 'Morning', Price: '16'},
                {ID: '4', Date: '4', Items: 'Tea', Quantity: '1',Type: 'Evening', Price: '8'},
                {ID: '5', Date: '5', Items: 'Coffee', Quantity: '1',Type: 'Morning', Price: '16'},
                {ID: '6', Date: '6', Items: 'Coffee', Quantity: '1',Type: 'Evening', Price: '16'},
                {ID: '7', Date: '7', Items: 'Coffee', Quantity: '1',Type: 'Morning', Price: '16'},
                {ID: '8', Date: '8', Items: 'Coffee', Quantity: '1',Type: 'Evening', Price: '16'},
                {ID: '9', Date: '9', Items: 'Coffee', Quantity: '1',Type: 'Morning', Price: '16'},
                {ID: '10', Date: '10', Items: 'Coffee', Quantity: '1',Type: 'Evening', Price: '16'},
                {ID: '11', Date: '11', Items: 'Coffee', Quantity: '1',Type: 'Morning', Price: '16'},
                {ID: '12', Date: '12', Items: 'Coffee', Quantity: '1',Type: 'Evening', Price: '16'},
                {ID: '13', Date: '13', Items: 'Coffee', Quantity: '1',Type: 'Morning', Price: '16'},
                {ID: '14', Date: '14', Items: 'Coffee', Quantity: '1',Type: 'Evening', Price: '16'},
                {ID: '15', Date: '15', Items: 'Coffee', Quantity: '1',Type: 'Morning', Price: '16'},
            ]
        }
    }
    render()
    {
        return(
            <View style={{flex: 1, padding:3,marginRight:-15, backgroundColor: '#2c4e54'}}>

                <View style={styles.header}>

                <IconButton style={{alignItems: "flex-end", marginTop: '5%',marginRight: '20%',marginLeft: -5}}
                    icon="arrow-left"
                    color={Colors.white}
                    size={30}
                    onPress={()=>this.props.navigation.goBack()}
                />
                     <Text style={{justifyContent: 'center',marginTop: 50, fontSize: 25, color: 'white'}}>Coupons</Text>
               
                </View>
              
                <View style={styles.footer}>
              
                <FlatList
                    data={this.state.DateList}
                    
                    renderItem={({item})=>
                        <Card style={{marginTop:25, borderRadius:20, marginBottom: 10, paddng:10, width: '98.5%', borderTopLeftRadius:20}}>
                            <View style={styles.cardview}>
                                <Text style={{flex:0.5, fontSize:15}}>Date</Text>
                                <Text style={{flex:0.5}}>{item.Date}</Text>
                            </View>

                            <View style={styles.cardview}>
                                <Text style={{flex:0.5, fontSize:15}}>Type</Text>
                                <Text style={{flex:0.5}}>{item.Type}</Text>
                            </View>

                            <View style={styles.cardview}>
                                <Text style={{flex:0.5, fontSize:15}}>Items</Text>
                                <Text style={{flex:0.5}}>{item.Items}</Text>
                            </View>

                            <View style={styles.cardview}>
                                <Text style={{flex:0.5, fontSize:15}}>Quantity</Text>
                                <Text style={{flex:0.5}}>{item.Quantity}</Text>
                            </View>

                            <View style={styles.cardview}>
                                <Text style={{flex:0.5, fontSize:15}}>Price</Text>
                                <Text style={{flex:0.5}}>{item.Price}</Text>
                            </View>
                        </Card>
                    }
                keyExtractor={item=>item.Id}
                />
             </View>
                  
        </View>
        )
    }
}

const styles= StyleSheet.create({
    cardview: {
        flex:5,
        padding: 5,
    
        marginTop: -10,
        marginRight: -10,
        marginBottom: 20,
        backgroundColor: 'white',
        flexDirection: 'row'

    },
    header: {
        flex: 0.1,
        backgroundColor: '#2c4e54',
        flexDirection: 'row'

    },
    footer: {
        flex: 0.9,
        backgroundColor: 'white',
        borderRadius: 30,
        backgroundColor: '#2c4e54',
        padding: 10
    }
})