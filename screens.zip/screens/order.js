import React from 'react';
import {Text, View, TouchableOpacity,StyleSheet, Alert} from 'react-native';

import { Table, TableWrapper, Row, Rows, Col, Cols, Cell } from 'react-native-table-component';
import { Divider } from 'react-native-elements';

export default class ordersummary extends React.Component{

  openTwoButtonAlert=()=>{
    Alert.alert(
      'Confirm?',
      'Do you want to generate the coupon?',
      [
        {text: 'Confirm', onPress: () => console.log('Yes button clicked')},
        {text: 'Cancel', onPress: () => console.log('No button clicked'), style: 'cancel'},
      ],
      { 
        cancelable: true 
      }
    );
  }

    render(){
 
     const array =  this.props.navigation.getParam('P1', 'nothing sent')
     const array2 =  this.props.navigation.getParam('P2', 'nothing sent')
     const array3 = ['Item', 'Price']
     const heightarray = []
  
     var totalPrice = array2.reduce(function(prev, curr){
      return (Number(prev) || 0) + (Number(curr) || 0);
  });
     for (var i = 0; i < array.length; i++) {
      heightarray.push(30);
     
    }
    
      
     

      

        return(
            
      <View style={styles.container}>
          <View style={styles.header}>
               <Text style={{justifyContent: 'center',marginLeft:'30%',marginTop: 50, fontSize: 25, color: 'white'}}>Order Summary</Text>
               
          </View>

          <View style={styles.footer}>
             <Table >
               <Row data={array3} flexArr={[0.5, 0.5]} style={styles.head} textStyle={styles.text1}/>
               <Divider/>
                <Col data={array} style={styles.title} heightArr={heightarray} textStyle={styles.text}/>
                <Col data={array2} style={styles.title1} heightArr={heightarray} textStyle={styles.text}/>
              
              </Table>
              
              <Divider style={{position: 'absolute', marginTop: '100%'}}/>
              <Text style={{position: 'absolute', marginBottom: -50,marginLeft:'34%', marginTop: '100%', fontSize:18}}> Your bill is Rs{totalPrice}</Text>
              
           
                    
                    <TouchableOpacity style={styles.textbox3} onPress={this.openTwoButtonAlert}>
                        <Text style={styles.headtext}>Generate Coupon</Text>
                    </TouchableOpacity>
           
               
            </View>
            </View>

        )
    }
  
    
}
const styles=StyleSheet.create({
  container: {
    flex:1
},
header:{
    flex: 0.15,
    backgroundColor: '#2c4e54'
},
footer: {
  flex: 1,
  backgroundColor: 'white',
  borderRadius: 30
},
  
textbox3: {
  marginTop: '90%',
  marginLeft: '25%',
  marginRight: 20,
  borderWidth: 1,
  width: '50%',
  alignItems: "center",
  height: 50,
  borderRadius: 25,
  borderColor: '#2c4e54',
  backgroundColor: "white"

},
headtext: {
  color: "#2c4e54",
  marginTop: 10,
  fontSize: 20,
},
title1: { flex: 1,marginLeft: '50%', backgroundColor: '#f6f8fa',marginLeft: '60%' },
title: { flex: 1, backgroundColor: '#f6f8fa', marginLeft:75 },
head: { height: 80, backgroundColor: 'white' , marginLeft:75 },
text: { margin: 6, fontSize: 18 },
text1: { margin: 6, fontSize: 22 }
});

