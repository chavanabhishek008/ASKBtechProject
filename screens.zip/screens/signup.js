import React, { useState } from 'react';
import { StyleSheet, Text, View, Image,TextInput, TouchableOpacity } from 'react-native';
//import {Picker} from 'react-native-picker-select';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {Picker} from '@react-native-community/picker';
const signup = ({navigation, route}) => {
  
  const [StudentName, setStudentName] = useState("");
  const [MIS, setMIS] = useState("");
  const [Email, setEmail] = useState("");
  const [Phonenumber, setPhonenumber] = useState("");
  const [YearofAdmission, setYearofAdmission] = useState("");
  const [Password, setPassword] = useState("");
  const [confirmPassword, setconfirmPassword] = useState("");
  const [selectedValue, setSelectedValue] = useState("");
  const [isError, setisError] = useState("");

  const check=(confirmPassword)=>{
    if(Password === confirmPassword){
      setconfirmPassword(confirmPassword) 
    }
    else{
      setisError("Passwords don't match!")
    }
    
  };

    return (

      <KeyboardAwareScrollView>

      
      <View style={styles.container}>
      <View style={styles.header}>
        <Image style={styles.image} source={require("../assets/plate2.png")} />
      </View>
        
    
     
       
          
          <View style={styles.footer}>
          
            <View style={styles.title}>
            <Text style={styles.titletext}>Register with us!</Text>
            </View>
            
          
            <View style={styles.inputView}>
             
             <TextInput
               style={styles.textinput}
               placeholder="StudentName"
               placeholderTextColor="#666"
               autoCapitalize="none"
               autoCorrect={false}
               onChangeText={(StudentName) => setStudentName(StudentName)} />
                <View style={styles.iconStyle}>
                <AntDesign name= {"user"} size={25} color='#666' />
            </View> 
           </View>

           <View style={styles.inputView}>           
             <TextInput
               style={styles.textinput}
               placeholder="MIS"
               placeholderTextColor="#666"
               autoCapitalize="none"
               keyboardType = 'number-pad'
               maxLength={9}
               autoCorrect={false}
               onChangeText={(MIS) => setMIS(MIS)} />
                <View style={styles.iconStyle}>
                <AntDesign name= {"user"} size={25} color='#666' />
            </View> 
           </View>

           <View style={styles.inputView}>            
             <TextInput
               style={styles.textinput}
               placeholder="Email"
               placeholderTextColor="#666"
               keyboardType="email-address"
               autoCapitalize="none"
               autoCorrect={false}
               onChangeText={(Email) => setEmail(Email)} /> 
                <View style={styles.iconStyle}>
                <AntDesign name= {"mail"} size={25} color='#666' />
            </View> 
           </View>

           <View style={styles.inputView}>
             
             <TextInput
               style={styles.textinput}
               placeholder="Phonenumber"
               placeholderTextColor="#666"
               autoCapitalize="none"
               maxLength={10}
               keyboardType = 'number-pad'
               autoCorrect={false}
               onChangeText={(Phonenumber) => setPhonenumber(Phonenumber)} /> 
                <View style={styles.iconStyle}>
                <AntDesign name= {"phone"} size={25} color='#666' />
            </View> 
           </View>

           <View style={styles.inputView}>
             
             <TextInput
               style={styles.textinput}
               placeholder="YearofAdmission(MM/YYYY)"
               maxLength={7}
               //keyboardType = 'numbers-and-punctuation'
               placeholderTextColor="#666"
               autoCapitalize="none"
               autoCorrect={false}
               onChangeText={(YearofAdmission) => setYearofAdmission(YearofAdmission)} />
                <View style={styles.iconStyle}>
                <AntDesign name= {"calendar"} size={25} color='#666' />
            </View> 
           </View>
      
        <View style={styles.inputView1}>
            <Picker style={styles.pickerStyle} 
              mode="dropdown"
              prompt= "Mess"
              selectedValue={selectedValue}
              style={styles.dropdown}
              onValueChange={(itemValue, itemIndex) => setSelectedValue(itemValue)}>
              <Picker.Item label="Mess" value="Mess" color="gray" />
              <Picker.Item label="SaeeMess" value="SaeeMess" />
              <Picker.Item label="BoysMess" value="BoysMess" />
            </Picker>
            <View style={styles.iconStyle1}>
              <AntDesign name= {"calendar"} size={25} color='#666' />
            </View> 
          </View>

           <View style={styles.inputView}>
           
             <TextInput
               style={styles.textinput}
               placeholder="Password"
               placeholderTextColor="#666"
               secureTextEntry={true}
               onChangeText={(Password) => setPassword(Password)}
             />
              <View style={styles.iconStyle}>
                <AntDesign name= {"lock"} size={25} color='#666' />
            </View> 
           </View>

           <View style={styles.inputView}>
           
           <TextInput
             style={styles.textinput}
             placeholder="ConfirmPassword"
             placeholderTextColor="#666"
             secureTextEntry={true}
             onChangeText={(confirmPassword) => check(confirmPassword)}
           />
            <View style={styles.iconStyle}>
              <AntDesign name= {"lock"} size={25} color='#666' />
          </View> 
         </View>
         <View style={{marginTop: 5, marginLeft:5}}>
         <Text style={{color: 'gray'}}>
            {isError}
          </Text>
           </View>
         
  

          <TouchableOpacity style={styles.loginBtn}
             onPress={() => {navigation.navigate("dashboard", {name: StudentName,
                                                                    email: Email,
                                                                    mobile: Phonenumber,
                                                                    MIS: MIS,
                                                                    password: Password})}}>
             <Text style={styles.loginText}>REGISTER</Text>   
          </TouchableOpacity>
          
          </View>
          
    </View>
    </KeyboardAwareScrollView>
      );
};

export default signup;

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    backgroundColor: '#2c4e54'
  },
  header: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center'
  },
  footer: {
      flex: 6,
      backgroundColor: '#fff',
      borderTopLeftRadius: 30,
      borderTopRightRadius: 30,
      paddingVertical: 50,
      paddingHorizontal: 30
  },
  title: {
    marginTop: -15,
    marginBottom: 5,
    marginLeft: 10
  },
  titletext: {
    color: "black",
    alignSelf: "flex-start",
    fontSize: 18,
  },
  image: {
    marginTop: -5,
    marginBottom: -5,
    marginLeft: '65%',
    justifyContent: 'flex-end',
    width: 120,
    height: 120,
  },
  iconStyle: {
    padding: 10,
    marginTop: -40,
    marginRight: '84%',
    height: '100%',
    //justifyContent: '',
    alignItems: 'flex-start',
    borderRightColor: '#ccc',
    borderRightWidth: 1,
    width: 50,
},
iconStyle1: {
  padding: 10,
  marginTop: -40,
  marginRight: '74%',
  height: '100%',
  //justifyContent: '',
  alignItems: 'flex-start',
  borderRightColor: '#ccc',
  borderRightWidth: 1,
  width: 50,
},
 
  inputView: {
    borderWidth: 1,
    borderRadius: 25,
    width: "100%",
    height: 45,
    borderColor: "gray",
    marginBottom: 0,
    marginTop: 15,
    marginRight: '5%',
    alignItems: "center",
    alignSelf: "center",
  },
  inputView1: {
    borderWidth: 1,
    borderRadius: 25,
    width: "100%",
    height: 45,
    marginTop: 15,
    marginLeft: -10,
    marginRight: '25%',
    borderColor: "gray"
  },
 
  textinput: {
    marginLeft: 53,
    height: 40,
    //flex: 1,
    padding: 10,
    color: "black",
    alignContent: "flex-start",
    alignSelf: "flex-start",
  },
  dropdown: {
    marginLeft: 53,
    height: 40,
    //flex: 1,
    padding: 10,
    color: "black",
  },
  loginBtn: {
    width: "95%",
    borderRadius: 25,
    height: 45,
    alignItems: "center",
    alignSelf: "center",
    justifyContent: "center",
    marginTop: 25,
    marginRight: '5%',
    backgroundColor: "#2c4e54",
  },
  loginText: {
    color: "#fff",
    alignSelf: "center",
    fontSize: 16,
  },
  pickerStyle:{  
    height: 40,  
    width: "80%",  
    color: 'gray',  
    justifyContent: 'center',  
}
});