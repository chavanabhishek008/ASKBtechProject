import React from 'react';
import {Text, View, StyleSheet} from 'react-native';
import { FlatList } from 'react-native-gesture-handler';
import {Card} from 'react-native-paper';

import { IconButton, Colors } from 'react-native-paper';

export default class PaymentHistory extends React.Component{

    constructor(props){
        super(props);
        this.state={
            DateList:[
                {ID: '1', Month: 'January', Payment: 'Rs 3420', Done: 'Yes'},
                {ID: '2', Month: 'February', Payment: 'Rs 2800', Done: 'Yes'},
                {ID: '3', Month: 'March', Payment: 'Rs 3520', Done: 'Yes'},
                {ID: '4', Month: 'April', Payment: 'Rs 2860', Done: 'Yes'},
                {ID: '5', Month: 'May', Payment: 'Rs 3400', Done: 'Yes'},
                {ID: '6', Month: 'June', Payment: 'Rs 3420', Done: 'Pending'},
                
            ]
        }
    }

    render(){
        return(
            <View style={styles.container}>
                <View style={styles.header}>

                    <IconButton style={{alignItems: "flex-end", marginTop: '5%',marginRight: '20%',marginLeft: -5}}
                    icon="arrow-left"
                    color={Colors.white}
                    size={30}
                    onPress={()=>this.props.navigation.goBack()}
                />
                     <Text style={{justifyContent: 'center',marginTop: 50, fontSize: 25, color: 'white'}}>PaymentHistory</Text>
                     
                </View>

                <View style={styles.footer}>
                <FlatList
                    data={this.state.DateList}
                    
                    renderItem={({item})=>
                        <Card style={{marginTop:25, borderRadius:20,width: '98.5%'}}>
                            <View style={styles.cardview}>
                                <Text style={{flex:0.5, fontSize:15}}>Month</Text>
                                <Text style={{flex:0.5}}>{item.Month}</Text>
                            </View>

                            <View style={styles.cardview}>
                                <Text style={{flex:0.5, fontSize:15}}>Bill</Text>
                                <Text style={{flex:0.5}}>{item.Payment}</Text>
                            </View>

                            <View style={styles.cardview}>
                                <Text style={{flex:0.5, fontSize:15}}>Done?</Text>
                                <Text style={{flex:0.5}}>{item.Done}</Text>
                            </View>

                        </Card>
                    }
                keyExtractor={item=>item.Id}
                />
           
  
                </View>

            </View>
        )
    }
}

const styles=StyleSheet.create({
    container: {
        flex:1
    },
    header:{
        flex: 0.1,
        backgroundColor: '#2c4e54',
        flexDirection: 'row'
    },
    footer: {
        flex: 0.9,
        backgroundColor: '#2c4e54',
        
      
    },
    cardview: {
        flex:5,
        padding: 10,
        borderRadius: 30,
        marginTop: -10,
        marginRight: -10,
        backgroundColor: 'white',
        flexDirection: 'row'

    }
})