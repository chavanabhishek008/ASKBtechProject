import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  TouchableOpacity,
} from "react-native";

import AntDesign from 'react-native-vector-icons/AntDesign';
 
const login = ({navigation}) => {

  const [username, setusername] = useState("");
  const [password, setPassword] = useState("");



  return (
 
     <View style={styles.container}>
    
      <Image style={styles.image} source={require("../assets/plate1.png")} />

      <View style={styles.inputView}>
             
        <TextInput
          style={styles.TextInput}
          placeholder="UserID"
          placeholderTextColor="#666"
          autoCapitalize="none"
          autoCorrect={false}
          onChangeText={(username) => setusername(username)}
        />
            <View style={styles.iconStyle}>
                <AntDesign name= {"user"} size={25} color='#666' />
            </View> 
      </View>
 
      <View style={styles.inputView}>
      
        <TextInput
          style={styles.TextInput}
          placeholder="Password"
          placeholderTextColor="#666"
          secureTextEntry={true}
          onChangeText={(password) => setPassword(password)}
        />
            <View style={styles.iconStyle}>
                <AntDesign name= {"lock"} size={25} color='#666' />
            </View>
      </View>

      <TouchableOpacity
      onPress={() => navigation.navigate("ForgotPassword")}>
        <Text style={styles.new_user}>Forgot Password? Click here</Text>
      </TouchableOpacity>
 
      <TouchableOpacity style={styles.loginBtn}
       onPress={() => navigation.navigate("dashboard")}>
        <Text style={styles.loginText}>LOGIN</Text>   
      </TouchableOpacity>

      <TouchableOpacity style={styles.loginBtn1}
         onPress={() => navigation.navigate("signup")}>
        <Text style={styles.loginText1}>New User? REGISTER</Text>
      </TouchableOpacity>
    </View>

    
  );
};

export default login;
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    justifyContent: "flex-start",
    //marginTop: '20%'
  },
  
  image: {
    marginTop: 70,
    marginBottom: -40,
    marginLeft: '20%',
    justifyContent: 'center',
    width: 250,
    height: 250,
  },

  iconStyle: {
    padding: 10,
    marginTop: -40,
    marginLeft: -230,
    height: '100%',
    //justifyContent: '',
    alignItems: 'flex-start',
    borderRightColor: '#ccc',
    borderRightWidth: 1,
    width: 50,
},
 
  inputView: {
    borderWidth: 1,
    borderRadius: 25,
    width: "70%",
    height: 45,
    borderColor: "gray",
    marginBottom: 10,
    marginTop: 20,
    alignItems: "center",
    alignSelf: "center",
  },
 
  TextInput: {
    marginLeft: 55,
    height: 40,
    //flex: 1,
    padding: 10,
    color: "black",
    alignContent: "flex-start",
    alignSelf: "flex-start",
  },
 
  new_user: {
    height: 30,
    marginBottom: 20,
    alignSelf: "center",
  },
 
  loginBtn: {
    width: "70%",
    borderRadius: 25,
    height: 45,
    alignItems: "center",
    alignSelf: "center",
    justifyContent: "center",
    marginTop: 10,
    backgroundColor: "#2c4e54",
  },
  loginBtn1: {
    width: "70%",
    borderRadius: 25,
    height: 45,
    alignItems: "center",
    alignSelf: "center",
    justifyContent: "center",
    borderWidth: 1,
    marginTop: 10,
    borderColor: "#2c4e54",
  },

  title: {
    
    fontSize: 28,
    fontWeight: 'bold',
    color: "black",
    fontFamily: "serif",
    marginLeft: 10,
    alignItems: "center",
    justifyContent: "center",
  },

  loginText: {
    color: "#fff",
    alignSelf: "center",
    fontSize: 16,
  },
  loginText1: {
    color: "#2c4e54",
    alignSelf: "center",
    fontSize: 16,
  }
});

