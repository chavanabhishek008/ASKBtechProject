import React, { Component, useState } from 'react';
import { Text, SafeAreaView, View,TouchableOpacity, TextInput, StyleSheet,Alert } from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';

const ForgotPassword = ({navigation}) => {

  const [Password, setPassword] = useState("");
  const [confirmPassword, setconfirmPassword] = useState("");
  const [isError, setisError] = useState("");

  
    const openTwoButtonAlert=()=>{
      Alert.alert(
        'Confirm?',
        'Do you want to reset the password?',
        [
          {text: 'Confirm', onPress: () => navigation.navigate("Loginpage")},
          {text: 'Cancel', onPress: () => console.log('No button clicked'), style: 'cancel'},
        ],
        { 
          cancelable: true 
        }
      );
    }

    
  const check=(confirmPassword)=>{
    if(Password === confirmPassword){
      setconfirmPassword(confirmPassword) 
    }
    else{
      setisError("Passwords don't match!")
    }
    
  };
    return(

    
        <View style={styles.container}>
         <View style={styles.header}>
        
         </View>
         
          
          <View style={styles.footer}>

              <Text style={{fontSize:18, color: '#2c4e54',marginTop: 20, marginLeft:1}}>ForgotPassword?</Text>

                 <View style={styles.inputView}>            
                    <TextInput
                    style={styles.textinput}
                    placeholder="Enter you EmailID"
                    placeholderTextColor="#666"
                    keyboardType="email-address"
                    autoCapitalize="none"
                    autoCorrect={false}
                   // onChangeText={(Email) => setEmail(Email)}
                    /> 
                        <View style={styles.iconStyle}>
                        <AntDesign name= {"mail"} size={25} color='#666' />
                    </View> 
                </View>

          <View style={styles.inputView}>
           
           <TextInput
             style={styles.textinput}
             placeholder="Password"
             placeholderTextColor="#666"
             secureTextEntry={true}
             onChangeText={(Password) => setPassword(Password)}
           />
            <View style={styles.iconStyle}>
              <AntDesign name= {"lock"} size={25} color='#666' />
          </View> 
         </View>

        <View style={styles.inputView}>
         <TextInput
           style={styles.textinput}
           placeholder="ConfirmPassword"
           placeholderTextColor="#666"
           secureTextEntry={true}
           onChangeText={(confirmPassword) => check(confirmPassword)}
         />
          <View style={styles.iconStyle}>
            <AntDesign name= {"lock"} size={25} color='#666' />
        </View> 
       </View>

       <View style={{marginTop: 5, marginLeft:5}}>
          <Text style={{color: 'gray'}}>{isError}</Text>
         </View>



                <TouchableOpacity style={styles.loginBtn1}
                  onPress={()=> openTwoButtonAlert()}
                   >
                    <Text style={styles.loginText1}>Reset?</Text>
                </TouchableOpacity>
         </View>
</View>


);
    };
           
export default ForgotPassword;

const styles = StyleSheet.create({
    container: {
      flex: 1, 
      backgroundColor: '#2c4e54'
    },
    header: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    footer: {
        flex: 6,
        backgroundColor: '#fff',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        paddingVertical: 50,
        paddingHorizontal: 30
    },
    loginBtn1: {
        width: "70%",
        borderRadius: 25,
        height: 45,
        alignItems: "center",
        alignSelf: "center",
        justifyContent: "center",
        borderWidth: 1,
        marginTop: 30,
        borderColor: "gray",
      },
      iconStyle: {
        padding: 10,
        marginTop: -40,
        marginRight: '84%',
        height: '100%',
        //justifyContent: '',
        alignItems: 'flex-start',
        borderRightColor: '#ccc',
        borderRightWidth: 1,
        width: 50,
    },
    inputView: {
        borderWidth: 1,
        borderRadius: 25,
        width: "100%",
        height: 45,
        borderColor: "gray",
        marginBottom: 0,
        marginTop: 15,
        marginRight: '5%',
        alignItems: "center",
        alignSelf: "center",
      },
      textinput: {
        marginLeft: 53,
        height: 40,
        //flex: 1,
        padding: 10,
        color: "black",
        alignContent: "flex-start",
        alignSelf: "flex-start",
      },
    
    loginText1: {
      color: "#2c4e54",
      alignSelf: "center",
      fontSize: 16,
    }
    });