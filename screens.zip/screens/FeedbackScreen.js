import { StatusBar } from "expo-status-bar";
import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TextInput,
  Button,
  Animated,
  Easing,
  TouchableOpacity,
  TouchableWithoutFeedback,
} from "react-native";
import Feedback from "./Rating";
import Rating from './Rating';
import { IconButton, Colors } from 'react-native-paper';

const FeedbackScreen = ({navigation})=> {

    return(
        <View style={styles.container}>
            <StatusBar style="auto" />
            <View style={styles.header}>
            
            <IconButton style={{alignItems: "flex-end", marginTop: '10%',marginLeft: '25%'}}
                icon="menu"
                color={Colors.white}
                size={30}
                onPress={navigation.toggleDrawer}
              />

              <Text style={{fontWeight: 'bold', fontSize: 25, color: 'white', alignSelf: 'center',justifyContent:'center'}}>FeedBack</Text>
          </View>

        <View style={styles.box}>
            <View style={styles.tab}>
                <Text style={styles.SubmitText}>TASTE</Text>
                <Rating rating={0} />
            </View>
            <View style={styles.tab}>
                <Text style={styles.SubmitText}>SERVICE</Text>
                <Rating rating={0} />
            </View>
            <View style={styles.tab}>
                <Text style={styles.SubmitText}>HYGIENE</Text>
                <Rating rating={0} />
            </View>
            
            <TouchableOpacity style={styles.loginBtn}>
                <Text style={styles.SubmitText1}>Submit</Text>
            </TouchableOpacity>

        </View>

        <View>
       
            <TextInput style={styles.textbox} placeholder="                        Help us know more..."></TextInput>
        </View>
        
        </View>
    )
}

export default FeedbackScreen;

const styles = StyleSheet.create({
    container: {
      flex: 1,

      
    },

    header: {
      //flex:0.08,
      height: '15%',
      backgroundColor: '#2c4e54',
      flexDirection: 'row-reverse'
    },

    head: {
        flex: 0.35,
        backgroundColor: "#2c4e54",
        alignContent: "center",
        justifyContent: "center",
        position: "absolute",
        width: "100%",
        height: "15%",
        


    },

    text1: {
        color: "#fff",
        alignSelf: "center",
        fontSize: 18
    },

    box: {
        alignSelf: "center",
        textAlign: "center",
        marginBottom: 0,
        position: "relative",
        marginTop: "40%",
    },

    tab: {
        marginTop: 10,
        marginBottom: 15,
    },

    loginBtn: {
        width: 100,
        borderRadius: 25,
        height: 45,
        alignItems: "center",
        alignSelf: "center",
        justifyContent: "center",
        marginTop: 10,
        backgroundColor: "#2c4e54",
      },

    SubmitText: {
        color: "black",
        alignSelf: "center",
        
        fontSize: 15,
        marginBottom: 4,
      },

      SubmitText1: {
        color: "#fff",
        alignSelf: "center",
        fontFamily: "serif",
        fontSize: 15,
        marginBottom: 4,
      },


    textbox: {
        position: "absolute",
        marginBottom: 10,
        marginLeft: '21%',
        marginRight: 30,
        marginVertical: 50,
        borderWidth: 1,
        height: 100,
        width: 250,
        textAlign: "left",
        
    }
})
