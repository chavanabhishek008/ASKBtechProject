import React,{Component} from 'react';
import {View,Image,StyleSheet,Text, TouchableOpacity, ImageBackground, Alert} from 'react-native';
import { RadioGroup } from 'react-native-btr';
import { IconButton, Colors } from 'react-native-paper';

//var bg=require('../assets/background1.jpg')
//var logo=require('../assets/menubg1.png');





export default class lunch extends Component
{
    constructor() {
 
        super();
     
        this.state = {
     
          radioButtons: [
            {
              label: '10:30 - 11:30',
              value: 1,
              checked: true,
              disabled: false,
              flexDirection: 'row',
              size: 5,
     
            },
     
            {
              label: '11:30 - 12:30',
              value: 2,
              checked: false,
              disabled: false,
              flexDirection: 'row',
              size: 5
     
            },
     
            {
              label: '12:30 - 1:30',
              value: 3,
              checked: false,
              disabled: false,
              flexDirection: "row",
              size: 5
     
            },
            {
                label: '1:30 - 2:30',
                value: 4,
                checked: false,
                disabled: false,
                flexDirection: 'row',
                size: 5
       
              },
              {
                label: 'Order for later ( Till 3)',
                value: 5,
                checked: false,
                disabled: false,
                flexDirection: 'row',
                size: 5
       
              }
     
          ]
     
        }
     
      }
      openTwoButtonAlert=()=>{
        Alert.alert(
          'Confirm?',
          'Do you want to generate the coupon?',
          [
            {text: 'Confirm', onPress: () => console.log('Yes button clicked')},
            {text: 'Cancel', onPress: () => console.log('No button clicked'), style: 'cancel'},
          ],
          { 
            cancelable: true 
          }
        );
      }
    
    render()
    {
        let selectedItem = this.state.radioButtons.find(e => e.checked == true);
    selectedItem = selectedItem ? selectedItem.value : this.state.radioButtons[0].value;
        return(

            <View style={styles.container}>
            
                <View style={styles.head}> 

                <IconButton style={{alignItems: "flex-start", marginTop: '5%',marginRight: '25%',marginLeft: -95}}
                    icon="arrow-left"
                    color={Colors.white}
                    size={30}
                    onPress={()=>this.props.navigation.goBack()}
                />
                    <Text style={{marginTop: 50, fontSize: 28, color: 'white',marginRight: '10%'}}>Lunch</Text>
                </View>
                <View>
                    <Text style={styles.textbox}>Menu for the Day!</Text>
                    <Text style={styles.textbox1}>
                        Vegetable1, Vegetable2, Rice, Dal, Chhapati, Curd, Salad
                    </Text>

                    <Text style={styles.textbox2}>Please select a suitable slot: </Text>
                <View style={styles.MainContainer}>
 
        <RadioGroup
          color='#2c4e54'
          labelStyle={{ fontSize: 14, }}
          radioButtons={this.state.radioButtons}
          onPress={radioButtons => this.setState({ radioButtons })}
          style={{ paddingTop: 3 }}
        />
 
      </View>
                    
                    <TouchableOpacity style={styles.textbox3} onPress={this.openTwoButtonAlert}>
                        <Text style={styles.headtext}>Generate Coupon</Text>
                    </TouchableOpacity>
                </View>
                


            </View>         
        );
    }

    
}
const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#fff",
      alignContent: "flex-end",
      alignItems: "center"
       
    },

    textbox: {
        alignSelf: "center",
        fontSize: 20,
        marginTop: 20,
    },

    head: {
        width: "100%",
        height: "12%",
        backgroundColor: "#2c4e54",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: 'row'
    },

    headtext: {
        color: "#fff",
        fontSize: 20,
    },

    textbox1: {
        width: 280,
        borderRadius: 10,
        borderWidth: 0.5,
        alignSelf: "center",
        height: "20%",
        marginTop: 20,
        marginLeft: 20,
        marginRight: 20,
        padding: 10,
        fontSize: 18,
        alignItems: "center",
        alignContent: "center",
        //backgroundColor: "#2c4e54"

    },
    textbox2: {
        marginTop: 20,
        marginLeft: 20,
        marginRight: 20,
        fontSize: 18,
        width: "100%",
        backgroundColor: "#fff"
    },

    textbox3: {
        marginTop: 10,
        marginLeft: 20,
        marginRight: 20,
        borderWidth: 1,
        justifyContent: "center",
        alignItems: "center",
        height: 50,
        borderRadius: 25,
        backgroundColor: "#2c4e54"

    },

    MainContainer: {
        flex: 0.75,

        justifyContent: 'center',
        alignItems: 'center',
        paddingTop: (Platform.OS) === 'ios' ? 20 : 0,
     
      },
     
      selectedItemView:
        {
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            padding: 10,
            backgroundColor: '#263238',
            justifyContent: 'center',
            alignItems: 'center'
        },
     
        selectedText:
        {
            fontSize: 17,
            color: '#fff'
        }



})