import React from 'react';
import {Text, View, TouchableOpacity,StyleSheet, Alert} from 'react-native';


export default class ordersummary extends React.Component{


    render(){
   
     const array =  this.props.navigation.getParam('P1', 'nothing sent')
     const totalPrice =  this.props.navigation.getParam('P2', 'nothing sent')
     //const result = array2.reduce((total, currentValue) => total = total + currentValue.array2,0);
     
    
    
     

        return(
            
            <View style={styles.header}> 
                
              
                    
                    <View style={styles.cardview}>
                                
                                <Text style={{flex:1}}>{array.toString()}</Text>
                                <Text>Your bill is {totalPrice}</Text>
                            </View>
                
            
            </View>

        )
    }
}
const styles=StyleSheet.create({
  header:{
    justifyContent: 'center',
    marginTop: 50
  },
  cardview: {
    flex:1,
    padding: 3,
    borderRadius: 30,
    borderColor: '#2c4e54',
    marginTop: 10,
    marginRight: 0,
    marginLeft: 10,
    backgroundColor: 'white',
  

},

 
})

