var express = require('express');
var router = express.Router();
var mysql = require('mysql');

var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "sakshi1",
  database: "btech"
});


router.post('/', function(req, res, next) {

  var username = req.body.username;
  var password = req.body.password;

  const sqlInsert= "SELECT * newt WHERE user_name = ? AND password = ?;"
    connection.query(sqlInsert,[username, password],  function(err, row, field) {
        if (err) {
            
            console.log("An error occurred.");
            res.send({ 'success': false, 'message': 'could not enter'})
           // result.send('sakshi')
        } 
        
        if( row > 0){
          res.send({ 'success': true, 'user': row[0].username});
        }
        else {
            // Throw a success message here.
            res.send({ 'success': false, 'message': 'user not found'})
          //  console.log("1 record successfully inserted into db");
        }
    });

});

module.exports = router;
/*
 const sqlInsert= "INSERT INTO newt (user_name, password) VALUES (?, ?);"
    connection.query(sqlInsert,[username, password],  function(err, result) {
        if (err) {
            
            console.log("An error occurred.");
            res.send({ 'success': false, 'message': 'could not enter'})
           // result.send('sakshi')
        } 
        
        else {
            // Throw a success message here.
            res.send({ 'success': true, 'message': 'done'})
            console.log("1 record successfully inserted into db");
        }
    });
*/