var express = require('express');
var router = express.Router();
var mysql = require('mysql');

var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "sakshi1",
  database: "btech"
});


router.post('/', function(req, res, next) {

  var StudentName = req.body.StudentName;
  var MIS = req.body.MIS;
  var Email = req.body.Email;
  var Phonenumber = req.body.Phonenumber;
  var YearofAdmission = req.body.YearofAdmission;
  var Password = req.body.Password;
  var selectedValue = req.body.selectedValue;
  

  const sqlInsert= "INSERT INTO user (user_name, StudentName, password, email, phone_no, YOA, mess_id) VALUES (?, ?, ?, ?, ?, ?, ?);"
    connection.query(sqlInsert,[MIS, StudentName, Password, Email, Phonenumber, YearofAdmission, selectedValue],  function(err, result) {
        if (err) {
            
            console.log("An error occurred.");
            res.send({ 'success': false, 'message': 'could not enter'})
           // result.send('sakshi')
        } 
        
        else {
            // Throw a success message here.
            res.send({ 'success': true, 'message': 'done'})
            console.log("1 record successfully inserted into db");
        }
    });

});

module.exports = router;
