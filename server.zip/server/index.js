const express = require('express');
const bodyParser = require('body-parser');
//const jwt = require('jsonwebtoken');
const cors = require('cors');
const app = express();
const mysql = require('mysql');

const db = mysql.createPool ({
    host: 'localhost',
    user: 'root',
    password: 'Kalyani18@',
    database: 'mess_system'
});

//const SECRETKEY = "Kals@123"
/*
const verifyTheToken = (req,res, next) => {
    //getting token from header
    const bearer = req.headers["authorization"]
    if (bearer) {
        const bearerToken = bearer.split(" ")
        const token = bearerToken[1]

        jwt.verify(token,SECRETKEY, (err, data) => {
            if(err){
                res.sendStatus(403)
                return;
            }
            else {
                req.userData = data
                next()
            }
        })
    }
    else {
        res.sendStatus(403)
        return;
    }
}
*/
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}));

app.get("/api/get", (req, res) => {
    
    const sqlGet = "SELECT * FROM manager";
    db.query(sqlGet, (err, result) => {
        res.send(result)
    })
})

app.post("/api/insert", (req,res) => {

    const username = req.body.username;
    const password = req.body.password;
    const phonenum = req.body.phonenum;
    const mess_id = req.body.mess_id;
    
    const sqlInsert = "INSERT INTO manager (username, password, phonenum, mess_id) VALUES (?,?,?,?);";
    db.query(sqlInsert, [username, password, phonenum,mess_id], (err, result) => {
        if(err) {

            console.log({err})
            return;
        }
        else {
            console.log(result);
        }
        
    })
    
})

app.post("/notification/insert", (req,res) => {

    const notification = req.body.notification_text;
    
    
    const sqlInsert = "INSERT INTO notification (notification_text, mess_id) VALUES (?,?);";
    db.query(sqlInsert, [notification, '1'], (err, result) => {
        console.log(result);
    })
    
})

app.post('/login',(req, res) => {
    const username = req.body.username;
    const password = req.body.password;
    //const phonenum = req.body.phonenum;
    //Database authenticate username and password
    
    const sqlLogin = "SELECT * from manager WHERE username = ? AND password = ?;";
    db.query(sqlLogin, [username, password], (err, result) => {
        if(err) {
            res.sendStatus(403)
            return;
        }
        else {
            if( result) {
                res.send(result);
            }
            else {
                res.send({message: "Wrong username and password combination"});
                return;
            }
        }  
    })
    /*
        const user = {
            username,
            password
        }
        jwt.sign({user},SECRETKEY,(err, token) => {
            if(err){
                res.sendStatus(403)
                return;
            }
            else {
                res.json({
                    token
                })
            }
        })
   */
})
/*
app.post("/delete-user",verifyTheToken, (req,res) => {
    console.log("Userdata: ",req.userData)
    res.send("user deleted")
})
*/
app.listen(3001, () => {
    console.log("Running on port 3001")
});

/* 
*/