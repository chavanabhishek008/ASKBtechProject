import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Menu from './components/menu';
import Dashboard from './components/Dashboard';
import Notification from './components/Notification';
import Sidebar from './components/sidebar/Sidebar';
import Tabs from './components/tabs/tabs';
import Navbar from './components/navbar/Navbar';
import Profile from './components/Profile';
import About from './components/About';
import Statistics from './components/Statistics';
import Feedback from './components/Feedback';
import history from './components/history';
import Login from './components/login';
import Register from './components/register';
import Main from './components/main';
import LoginUs from './components/signup-fake';
import Logout from './components/logout';

export default class App extends Component {
    constructor() {
        super();

    }

    render() {
        return (
            <Router history={history}>
                <Switch>
                    <Route 
                    exact path="/" 
                    render= { props => (
                        <Main />
                    )} /> 
                    <Route 
                    exact path="/Dashboard" render= { props => (
                        <Dashboard />
                    )}/>
                    
                    <Route path="/Navbar" component={Navbar} />
                    <Route path="/Sidebar" component={Sidebar} />
                    <Route path="/Tabs" component={Tabs} />
                    <Route path="/Profile" component={Profile} />
                    <Route path="/Menu" component={Menu} />
                    <Route path="/Notification" component={Notification} />
                    <Route path="/About" component={About} />
                    <Route path="/Feedback" component={Feedback} />
                    <Route path="/Statistics" component={Statistics} />
                    <Route path="/Logout" component={Logout} />
                    <Route path="/Login" 
                     render= { props => (
                        <LoginUs  />
                    )} />
                </Switch>
            </Router>
        )
    }
}