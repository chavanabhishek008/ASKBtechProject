
import React from "react";
import "./main.css";
import Login  from './login';
import Register from './register';
import LoginUs from './signup-fake';
import "./style.scss";
import { useHistory } from 'react-router-dom';
//import history from './history';
//import {BrowserRouter as Router} from 'react-router-dom';
import {Dashboard} from './Dashboard';
import {Redirect} from "react-router-dom";
import Axios from 'axios';

export default class Main extends React.Component {

  /*state ={}

  componentDidMount() {
    const config = {
      headers: {
        Authorization: 'Bearer' + localStorage.getItem('token')
      }
    };
    Axios.get('user', config).then(
      res => {
        this.setState({
          user: res.data
        });
      },
      err => {
        console.log(err);
      }
    )
  }*/
  constructor(props) {
    super(props);

    
    const { history } = this.props;
    /*
    this.state = {
      isLogginActive: true
    };
    */
  
    this.handleSuccessfulAuth = this.handleSuccessfulAuth.bind(this);
  }

  
  handleSuccessfulAuth(data) {
    this.props.handleLogin(data);
    this.props.history.push('/Dashboard');
  }

  render() {
    return (
      <div>
        <Register handleSuccessfulAuth={this.handleSuccessfulAuth}/>
        <div>
        </div>
      </div>
    )
  }
}
  
/*
  changeState() {
    const { isLogginActive } = this.state;

    if (isLogginActive) {
      this.rightSide.classList.remove("right");
      this.rightSide.classList.add("left");
    } else {
      this.rightSide.classList.remove("left");
      this.rightSide.classList.add("right");
    }
    this.setState(prevState => ({ isLogginActive: !prevState.isLogginActive }));
  }
*/
/*
  render() {
    const { isLogginActive } = this.state;
    const current = isLogginActive ? "Register" : "Login";
    const currentActive = isLogginActive ? "login" : "register";
    return (
      <div className="App">
        <div className="login">
          <div className="container" ref={ref => (this.container = ref)}>
            {isLogginActive && (
              <Login containerRef={ref => (this.current = ref)} />
            )}
            {!isLogginActive && (
              <Register handleSuccessfulAuth={this.handleSuccessfulAuth} containerRef={ref => (this.current = ref)} />
            )}
          </div>
          <RightSide
            current={current}
            currentActive={currentActive}
            containerRef={ref => (this.rightSide = ref)}
            onClick={this.changeState.bind(this)}
          />
        </div>
      </div>
    );
  }
}
export default Main;*/
/*
const RightSide = props => {
  return (
    <div
      className="right-side"
      ref={props.containerRef}
      onClick={props.onClick}
    >
      <div className="inner-container">
        <div className="text">{props.current}</div>
      </div>
    </div>
  );
};
*/


