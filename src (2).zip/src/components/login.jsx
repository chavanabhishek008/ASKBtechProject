
import React, {useState, useEffect} from "react";
import Axios from 'axios';
import Freepik from '../assets/plate2.png';

function Login ( props ) {

  const [usernameLog, setusernameLog] = useState("");
  const [passwordLog, setpasswordLog] = useState("");
  const [Loginstatus, setLoginstatus] = useState("");
/*
  this.state = {
    username: "",
    password: "",
  };

  this.handeSubmit = this.handleSubmit.bind(this);
  this.handleChange = this.handleChange.bind(this);

  handleChange(event){
    this.setState({
      [event.target.name] : event.target.value
    });
  }

*/

  const loginform = () => {
    Axios.post("http://localhost:3001/login",{
    username: usernameLog, 
    password: passwordLog, 
    }).then((response)=> {
      if(response.data.message) {
        setLoginstatus(response.data.message);
      }
      else {
        setLoginstatus(response.data[0].phonenum);
      }
    });
  };

    return (
      <div className="base-container" >
        <div className="header">Login</div>
        <div className="content">
          <div className="image">
            <img src={Freepik} />
          </div>
          <form className="form">
            <div className="form-group">
              <label htmlFor="username">Username</label>
              <input type="text" name="username" placeholder="username" onChange={(e) => {
                setusernameLog(e.target.value);
              }}/>
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input type="password" name="password" placeholder="password" onChange={(e) => {
                setpasswordLog(e.target.value);
              }}/>
            </div>
            <div className="footer">
          <button type="submit" className="button1" onClick={loginform}>
            Login
          </button>
        </div>
          </form>
        </div>
        <h2>{Loginstatus}</h2>
      </div>
    );
  }
export default Login;

