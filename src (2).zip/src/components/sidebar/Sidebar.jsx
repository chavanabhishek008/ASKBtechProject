import './Sidebar.scss';
import logo from '../../assets/plate2.png';
import { Button } from 'bootstrap';
import {Profile} from '../Profile';
import {About} from '../About';
import {Statistics} from '../Statistics';
import {Feedback} from '../Feedback';
import history from '../history';
import {Link} from 'react-router-dom';
import {Logout} from '../logout';


const Sidebar = ({ sidebarOpen, closeSidebar}) => {
    const user_name = localStorage.getItem("username")
    return(
        <div className = {sidebarOpen ? "sidebar-responsive" : "" } id="sidebar">
            <div className="sidebar__title">
                <div className="sidebar__img">
                    <img src={logo} alt="logo" />
                    <h1>Hello, {user_name}</h1>
                </div>
                <i className="fa fa-times" id="sidebarIcon" onClick={() => closeSidebar()}></i>
            </div> 

            <div className="sidebar__menu">
                <div className="sidebar__link ">
                    <Link to="/Statistics" className="btn1"><i className="fa fa-bars"></i>   DASHBOARD</Link>
                </div>  
                <div className="sidebar__link">
                    <Link to="/Profile" className="btn1"><i className="fa fa-user"></i>   PROFILE</Link>
                    
                </div>  
                <div className="sidebar__link">
                    <Link to="/Statistics" className="btn1"><i className="fa fa-bar-chart"></i>  STATISTICS</Link>
                </div>
                <div className="sidebar__link">
                    <Link to="/Feedback" className="btn1"><i className="fa fa-comments-o"></i>  FEEDBACK</Link>  
                </div>       
                <div className="sidebar__link">
                    <Link to="/About" className="btn1"><i className="fa fa-question"></i>  ABOUT US</Link>
                </div>
                
                <div className="sidebar__link">
                   <Link to="/Logout" className="btn1"><i className="fa fa-sign-out"></i>  LOG OUT</Link>
                </div>
                
                
                
           </div>
        </div>
    )
}

export default Sidebar;

/*  <button className="btn"><i className="fa fa-sign-out"></i>  Log out</button>*/