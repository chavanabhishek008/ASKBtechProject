import React from 'react';
import logo from '../assets/plate2.png';
import './About.scss';

export default class About extends React.Component {
    constructor(props) {
        super(props);
    }
    render() { 
        return ( 
            <div className="base-container1">
                
                <div className="content">
                    <div className="header">ABOUT US</div>
                    <div className="image">
                        <img src={logo}/>
                    </div> 
                </div>
              
            </div>
         );
    }
}
 
