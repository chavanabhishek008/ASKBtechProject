import React from 'react';
import logo from '../assets/plate2.png';
import './Statistics.scss';

export default class Statistics extends React.Component {
    constructor(props) {
        super(props);
    }
    render() { 
        return ( 
            <div className="base-container1">
                
                <div className="content">
                    <div className="header">STATISTICS</div>
                    <div className="image">
                        <img src={logo}/>
                    </div> 
                </div>
              
            </div>
         );
    }
}
 
