import React from 'react';
import logo from '../assets/plate2.png';
import './Profile.scss';

export default class Profile extends React.Component {
    constructor(props) {
        super(props);
    }
    render() { 
        return ( 
            <div className="base-container">
                
                <div className="content">
                <div className="header">MANAGER PROFILE</div>
                    <div className="image">
                        <img src={logo}/>
                    </div> 
                </div>
            <div className="box-content">
                <p className="profile-text" ><i className="fa fa-user"></i>      Abhay Deshpande </p>
                <p className="profile-text"><i className="fa fa-key"></i>     *********</p>
                <p className="profile-text"><i className="fa fa-envelope"></i>     abhay12@gmail.com</p>
                <p className="profile-text"><i className="fa fa-phone"></i>     6776868768</p>
                <input className="profile-text" type="password" name="password" placeholder="****"></input>
                <button className="edit-profile"><i className="fa fa-edit"></i>      Edit Profile</button>
                   
            </div>   
            </div>
         );
    }
}
 
