import Freepik from '../assets/plate2.png';
import './register.scss';
import React, {useState, useEffect} from "react";
import Axios from 'axios';
import {Link} from 'react-router-dom';

/*
function Register() {
  const [username, setusername] = useState("");
  const [password, setpassword] = useState("");
  const [phonenum, setphonenum] = useState("");

  const submitForm = () => {
    Axios.post("http://localhost:3001/api/insert",{
      username: username, 
      password: password, 
      phonenum: phonenum,
    
    }).then(response => {
      if(response.data.status === 'created'){
      this.props.handleSuccessfulAuth(response.data)}
    });
  };

    return (
      <div className="base-container" >
        <div className="header">Register for Repast</div>
        <div className="content">
          <div className="image">
            <img src={Freepik}  />
          </div>
          <form className="form" >
            <div className="form-group">
              <label htmlFor="username">Username</label>
              <input type="text"  name="username" placeholder="username" onChange={(e) => {
                setusername(e.target.value);
              }}/>
            </div>
            <div className="form-group">
              <label htmlFor="email">Phone number</label>
              <input type="text"  name="phonenum" placeholder="Phonenumber" onChange={(e) => {
                setphonenum(e.target.value);
              }}/>
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input type="password"  name="password" placeholder="password" onChange={(e) => {
                setpassword(e.target.value);
              }}/>
            </div>
          
            
            <div className="footer">
          <button type="submit" value="Submit" className="button1" onClick={submitForm}>
            Register
          </button>

        </div>
          </form>
        </div>
        
      </div>
    );
  }
export default Register;


/**
            <div className="form-group">
              <label htmlFor="confmpassword">Confirm password</label>
              <input type="password" name="confmpassword" placeholder="re-enter your password" />
            </div> */

export default class Register extends React.Component {

  constructor(props) {
    super(props);

    this.state ={
      username: "",
      password: "",
      phonenum: "",
      mess_id: ""
    }

    this.submitForm = this.submitForm.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
 

  submitForm() {
    Axios.post("http://localhost:3001/api/insert",{
      username: this.state.username, 
      password: this.state.password, 
      phonenum: this.state.phonenum,
      mess_id: this.state.mess_id,
  }
  )
  .catch(error => {
    console.log("registration error", error);
    return;
  })
  }

  handleChange(event) {
    this.setState({
      [event.target.name]: event.target.value
    })
  }

  render() {
    return (
      <div className="box4">
        <div className='header'>
        <h3>Register with Repast</h3>
        </div>
        <div className="box3">
        <form onSubmit={this.submitForm}>
        <input className = "formHorizontal2" type="text" name="username" placeholder="username" value={this.state.username} onChange={this.handleChange}></input>
        <div></div>
        <input className = "formHorizontal2" type="password" name="password" placeholder="password" value={this.state.password} onChange={this.handleChange}></input>
        <div></div>
        <input className = "formHorizontal2" type="text" name="phonenum" placeholder="phonenum" value={this.state.phonenum} onChange={this.handleChange}></input>
        <div></div>
        <input className = "formHorizontal2" type="text" name="mess_id" placeholder="mess_id" value={this.state.mess_id} onChange={this.handleChange}></input>
        <button className = "btn" type="submit">Register</button>
        </form>
        <div className='header'>
        <h3>Already registered? <Link to="/Login">Login</Link></h3>
        </div>
        
        </div>
        
      </div>
    );
  }
}