import React,{useState} from 'react';
import './dashboard.scss';
import Navbar from './navbar/Navbar';
import Sidebar from './sidebar/Sidebar';
import Tabs from './tabs/tabs';
import {Redirect } from 'react-router-dom';

export default class Dashboard extends React.Component {

    constructor(props) {
        super(props) 
        const token = localStorage.getItem("token")
        const user_name = localStorage.getItem("username")

        let loggedIn = true
        if(token == null) {
            loggedIn = false
        }

    this.state = {
        loggedIn,
        user_name
    }
}
    
    render() {
        if(this.state.loggedIn == false) {
            return <Redirect to="/Login" />
        } 
       // const [sidebarOpen, setSidebarOpen] = useState(false);

    /*const openSidebar = () => {
        setSidebarOpen(true);
    }

    const closeSidebar = () => {
        setSidebarOpen(false);
    }*/
        return (
            <div className="container">
                <Tabs/>
                
                <Sidebar /*sidebarOpen={sidebarOpen} closeSidebar={closeSidebar}*//> 
            </div>
        );
    }
    
    }

    
    



/*
<Navbar sidebarOpen={sidebarOpen} openSidebar={openSidebar}/>
*/