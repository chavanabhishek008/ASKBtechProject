import React, {useState, useEffect} from "react";
import Axios from 'axios';
import './signup-fake.scss'
import {Redirect} from "react-router-dom";

export default class LoginUs extends React.Component {

  constructor(props) {
    super(props);
    
    let loggedIn = true
    const token = localStorage.getItem("token")
        if(token == null) {
            loggedIn = false
        }
    this.state = {
      username: '',
      password: '',
      loggedIn
    }
    this.onChange = this.onChange.bind(this);
    this.submitform = this.submitform.bind(this);
  }
  onChange(e) {
    this.setState({
      [e.target.name] : e.target.value
    })
  }

  submitform(e) {
    e.preventDefault()
    const { username, password } = this.state
    Axios.post("http://localhost:3001/login",{
        username: username, 
        password: password, 
        })
        .then((response)=> {
          if(response.data.message) {
            console.log("Wrong username or password")
          }
          else {
            console.log("hchcuh")
            localStorage.setItem("token","vcuqucqvucvuqcuy")
            localStorage.setItem("username",username)
            //localStorage.setItem("mess_id",mess_id)
            this.setState({
              loggedIn: true
            })
          }
        });
    
  }

  

  render() {
    if(this.state.loggedIn) {
      return <Redirect to="/Dashboard"/>
    }
    return (
      <div className="box4">
        <div className='header'>
        <h1 >REPAST</h1>
        </div>
        
        <div className="box3">
        <form onSubmit={this.submitform}>
        <input className = "formHorizontal2" type="text" name="username" placeholder="username" value={this.state.username} onChange={this.onChange}></input>
        <div></div>
        <input className = "formHorizontal2" type="password" name="password" placeholder="password"  value={this.state.password} onChange={this.onChange}></input>
        <div></div>
        
        
        <button className = "btn" type="submit">Login</button>
        </form>
        </div>
        
      </div>
    );
  }
}