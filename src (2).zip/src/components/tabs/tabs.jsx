import './tabs.scss';
import logo from '../../assets/header.jpg';
import graph from '../../assets/graph1.png';
import { useHistory } from 'react-router-dom';
import {Notification} from '../Notification';
import {Menu} from '../menu';
import history from '../history';
import {BrowserRouter as router} from 'react-router-dom';
const Tab = () => {

    return(
        <main >
            <div className="main__container">
                <div className="main__title">
                    <img src={logo} alt="logo"/>
                    <div className="main__greeting">
                        <h1>Welcome to the admin board</h1>
                    </div>
                </div>
            <div className="main__cards">
                <button className="card" onClick={() => history.push('/Menu')}>
                    <i className="fa fa-list fa-2x text-lightblue"></i>
                    <div className="card_inner">
                        <p className="text-primary-p">Menu Updation</p>
                    </div>
                </button>
                
                <button className="card">
                    <i className="fa fa-laptop fa-2x text-lightblue"></i>
                    <div className="card_inner">
                        <p className="text-primary-p">Student Details</p>
                    </div>
                </button>
                
                <button className="card" onClick={() => history.push('/Notification')}>
                    <i className="fa fa-bell fa-2x text-lightblue"></i>
                    <div className="card_inner">
                        <p className="text-primary-p">Notification</p>
                    </div>
                </button>

                <button className="card">
                    <i className="fa fa-edit fa-2x text-lightblue"></i>
                    <div className="card_inner">
                        <p className="text-primary-p">Transactions</p>
                    </div>
                </button>

            </div>

            <div className="charts">
                <div className="charts__left">
                    <div className="charts__left__title">
                        <div>
                            <h1>Daily Reports</h1>
                            <p>Peak Hours </p>
                        </div>
                        <i className="fa fa-bar-chart"></i>
                    </div>
                    <img src={graph} alt="chart"></img>
                </div>
            </div>
            </div>


        </main>
    )
}

export default Tab;