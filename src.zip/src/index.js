import React from 'react';
import ReactDom from 'react-dom';
//import {BrowserRouter as Router} from 'react-router-dom';
import {Router, Route, browserHistory, IndexRoute} from 'react-router';
import './index.css';
import App from './App';
import Menu from './components/menu';

/*
import {Login} from './components/login';
import {Register} from './components/register';*/
/*//import 'bootstrap/dist/css/bootstrap.css';
import Dashboard from './components/Dashboard';

import {Notification} from './components/Notification';

import {Routes} from './components/Routes';
import Profile from './components/Profile';*/

/*class App extends React.Component {
    render() {
        return (
            <Router history={browserHistory}>
                <Route path={"/"} component={Dashboard}>
                    <Route path={"Login"} component={Login} />
                </Route>
            </Router>
        )
    }
}*/

ReactDom.render(<App />,document.getElementById('root'));