import Freepik from '../assets/plate2.png';

import React from "react";


export default class Register extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="base-container" ref={this.props.containerRef}>
        <div className="header">Register for Repast</div>
        <div className="content">
          <div className="image">
            <img src={Freepik}  />
          </div>
          <form className="form" >
            <div className="form-group">
              <label htmlFor="username">Username</label>
              <input type="text" name="username" placeholder="username" />
            </div>
            <div className="form-group">
              <label htmlFor="email">Phone number</label>
              <input type="text" name="phonenum" placeholder="Phonenumber" />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input type="password" name="password" placeholder="password" />
            </div>
          
            
            <div className="footer">
          <button type="submit" className="button1">
            Register
          </button>
        </div>
          </form>
        </div>
        
      </div>
    );
  }
}

/**
            <div className="form-group">
              <label htmlFor="confmpassword">Confirm password</label>
              <input type="password" name="confmpassword" placeholder="re-enter your password" />
            </div> */