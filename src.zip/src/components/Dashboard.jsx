import {useState} from 'react';
import './dashboard.scss';
import Navbar from './navbar/Navbar';
import Sidebar from './sidebar/Sidebar';
import Tabs from './tabs/tabs';

const Dashboard = () => {

    const [sidebarOpen, setSidebarOpen] = useState(false);

    const openSidebar = () => {
        setSidebarOpen(true);
    }

    const closeSidebar = () => {
        setSidebarOpen(false);
    }

    return (
        <div className="container">
            <Tabs/>
            <Sidebar sidebarOpen={sidebarOpen} closeSidebar={closeSidebar}/> 
        </div>
    );
}

export default Dashboard;
/*
<Navbar sidebarOpen={sidebarOpen} openSidebar={openSidebar}/>
*/