import './Sidebar.scss';
import logo from '../../assets/plate2.png';
import { Button } from 'bootstrap';
import {Profile} from '../Profile';
import {About} from '../About';
import {Statistics} from '../Statistics';
import {Feedback} from '../Feedback';
import history from '../history';

const Sidebar = ({ sidebarOpen, closeSidebar}) => {
    return(
        <div className = {sidebarOpen ? "sidebar-responsive" : "" } id="sidebar">
            <div className="sidebar__title">
                <div className="sidebar__img">
                    <img src={logo} alt="logo" />
                    <h1>Hello, Manager</h1>
                </div>
                <i className="fa fa-times" id="sidebarIcon" onClick={() => closeSidebar()}></i>
            </div> 

            <div className="sidebar__menu">
                <div className="sidebar__link ">
                    <button className="btn1"><i className="fa fa-bars"></i>    Dashboard</button>
                </div>  
                <div className="sidebar__link">
                    <button className="btn1" onClick={() => history.push('/Profile')}><i className="fa fa-user"></i>    Profile</button>
                </div>  
                <div className="sidebar__link">
                    <button className="btn1" onClick={() => history.push('/Statistics')}><i className="fa fa-bar-chart"></i>    Statistics</button>
                </div>
                <div className="sidebar__link">
                    <button className="btn1" onClick={() => history.push('/Feedback')}><i className="fa fa-comments-o"></i>    Feedback</button>   
                </div>       
                <div className="sidebar__link">
                    <button className="btn1" onClick={() => history.push('/About')}><i className="fa fa-question"></i>    About Us</button>
                </div>
                
                <div className="sidebar__link">
                    <button className="btn1"><i className="fa fa-sign-out"></i>    Log Out</button>   
                </div>
                
                
                
           </div>
        </div>
    )
}

export default Sidebar;

/*  <button className="btn"><i className="fa fa-sign-out"></i>  Log out</button>*/