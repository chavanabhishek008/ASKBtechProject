import React from 'react';
import './Notification.scss';
import plate2 from '../assets/plate2.png';

const Notification=()=> {
  
    return(
        <div className= 'box1'>
        <div class="toppane">
          <img src={plate2} alt="plate2"
           style={{
             width: 90,
             height: 90,
            
           }}
             />
          <h1 class='title'>Notifications</h1>
         </div>

        
        <div className="header1">
          <span className="noti">Notification 1</span>  
          <div></div>
          <input type="text" className="formHorizontal"  name="title" style={{padding: 8}}/>
          <div></div>
          <button type="button"  className="btn">Save</button>
        </div> 
        
        <div className="header2">
          <span className="noti2">Notification 2</span> 
          <div></div>
          <input type="text" className="formHorizontal2"  name="title" style={{padding: 8}} />
          <div></div>
          <button type="button"  className="btn2">Save</button>
        </div>
        
        <div className="header3">
          <span className="noti3">Notification 3</span> 
          <div></div>
          <input type="text" className="formHorizontal3"  name="title" style={{padding: 8}} />
          <div></div>
          <button type="button"  className="btn3">Save</button>
        </div>
        
         </div>
    )
}
export default Notification;