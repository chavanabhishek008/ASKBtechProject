
import React from "react";
import Freepik from '../assets/plate2.png';

export default class Login extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="base-container" ref={this.props.containerRef}>
        <div className="header">Login</div>
        <div className="content">
          <div className="image">
            <img src={Freepik} />
          </div>
          <form className="form">
            <div className="form-group">
              <label htmlFor="username">Username</label>
              <input type="text" name="username" placeholder="username" />
            </div>
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <input type="password" name="password" placeholder="password" />
            </div>
            <div className="footer">
          <button type="submit" className="button1">
            Login
          </button>
        </div>
          </form>
        </div>
        
      </div>
    );
  }
}

