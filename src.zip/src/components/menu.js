import React, { useState } from 'react';
import './menu.css';
import MultiSelect from "react-multi-select-component";
import Divider from '@material-ui/core/Divider';
import plate2 from '../assets/plate2.png';

const Menu = () =>{

  const options1 = [
    { label: "Vegetable 1", value: "Vegetable 1" },
    { label: "Vegetable 2", value: "Vegetable 2" },
    { label: "Vegetable 3", value: "Vegetable 3" },
    { label: "Roti", value: "Roti" },
    { label: "Rice", value: "Rice" },
    { label: "Daal", value: "Daal" },

  ];

  const options2 = [
    { label: "Raita", value: "Raita" },
    { label: "Dahi", value: "Dahi" },
    { label: "Sweet", value: "Sweet" },
    { label: "Roti", value: "Roti" },
    { label: "Rice", value: "Rice" },
    { label: "Daal", value: "Daal" },
  ];

  const options3 = [
    { label: "Vegetable 1", value: "Vegetable 1" },
    { label: "Vegetable 2", value: "Vegetable 2" },
    { label: "Vegetable 3", value: "Vegetable 3" },
    { label: "Roti", value: "Roti" },
    { label: "Rice", value: "Rice" },
    { label: "Daal", value: "Daal" },

  ];

  const options4 = [
    { label: "Raita", value: "Raita" },
    { label: "Dahi", value: "Dahi" },
    { label: "Sweet", value: "Sweet" },
    { label: "Roti", value: "Roti" },
    { label: "Rice", value: "Rice" },
    { label: "Daal", value: "Daal" },
  ];

  const options5 = [
    { label: "Poha", value: "Poha" },
    { label: "Upma", value: "Upma" },
    { label: "Sandwich", value: "Sandwich" },
    { label: "Veg Roll", value: "Veg Roll" },
    { label: "Bread", value: "Bread" },
    { label: "Khari", value: "Khari" },

  ];

  const options6 = [
    { label: "Milk", value: "Milk" },
    { label: "BornVita", value: "BornVita" },
    { label: "Coffee", value: "Coffee" },
    { label: "Tea", value: "Tea" },
    { label: "Juice 1", value: "Juice 1" },
    { label: "Juice 2", value: "Juice 2" },
  ];


  const [selected1, setSelected1] = useState([]);
  const [selected2, setSelected2] = useState([]);
  const [selected3, setSelected3] = useState([]);
  const [selected4, setSelected4] = useState([]);
  const [selected5, setSelected5] = useState([]);
  const [selected6, setSelected6] = useState([]);


  return(
    <div className= "box">
           <div class="toppane">
             <img src={plate2} alt="plate2"
              style={{
                width: 90,
                height: 90,
               
              }}
                />
             <h1 class='title'>Menu</h1>
            </div>
            <div class="leftpane">
              <h1 style={{marginLeft: '30%'}}>Lunch</h1>
                <Divider />
                <span style={{marginLeft: 10, justifySelf: 'center'}}>Select Menu</span>
                <pre>{JSON.stringify(selected1)}</pre>
                <MultiSelect
                  options={options1}
                  value={selected1}
                  onChange={setSelected1}
                  labelledBy={"Select"}
                  style={{marginLeft: 20}}
                />

                <Divider />
                <span style={{marginLeft: 10}}>Select Sides</span>
                <pre>{JSON.stringify(selected2)}</pre>
                <MultiSelect
                  options={options2}
                  value={selected2}
                  onChange={setSelected2}
                  labelledBy={"Select"}
                  style={{marginLeft: 10}}
                />
 
            </div>
            

            <div class="middlepane">
            <div class="leftpane1">
                <h1 style={{marginLeft: '30%'}}>Breakfast</h1>
                <Divider />

                <span style={{marginLeft: 10}}>Select Snacks</span>
                    <pre>{JSON.stringify(selected5)}</pre>
                    <MultiSelect
                      options={options5}
                      value={selected5}
                      onChange={setSelected5}
                      labelledBy={"Select"}
                      style={{marginLeft: 20}}
                    />
                    <Divider />

                    <span style={{marginLeft: 10}}>Select Beverage</span>
                    <pre>{JSON.stringify(selected6)}</pre>
                    <MultiSelect
                      options={options6}
                      value={selected6}
                      onChange={setSelected6}
                      labelledBy={"Select"}
                      style={{marginLeft: 10}}
                    />
                </div>
                <div class="rightpane1">
                <h1 style={{marginLeft: '30%'}}>Snacks</h1>
                <Divider />

                <span style={{marginLeft: 10}}>Select Snacks</span>
                    <pre>{JSON.stringify(selected5)}</pre>
                    <MultiSelect
                      options={options5}
                      value={selected5}
                      onChange={setSelected5}
                      labelledBy={"Select"}
                      style={{marginLeft: 20}}
                    />
                    <Divider />

                    <span style={{marginLeft: 10}}>Select Beverage</span>
                    <pre>{JSON.stringify(selected6)}</pre>
                    <MultiSelect
                      options={options6}
                      value={selected6}
                      onChange={setSelected6}
                      labelledBy={"Select"}
                      style={{marginLeft: 10}}
                    />
                </div>
            </div>
          

            <div class="rightpane">
              <h1 style={{marginLeft: '25%'}}>Dinner</h1>
              <Divider />
              <span style={{marginLeft: 10}}>Select Menu</span>
                <pre>{JSON.stringify(selected3)}</pre>
                <MultiSelect
                  options={options3}
                  value={selected3}
                  onChange={setSelected3}
                  labelledBy={"Select"}
                  style={{marginLeft: 20}}
                />
                <Divider />

                <span style={{marginLeft: 10}}>Select Sides</span>
                <pre>{JSON.stringify(selected4)}</pre>
                <MultiSelect
                  options={options4}
                  value={selected4}
                  onChange={setSelected4}
                  labelledBy={"Select"}
                  style={{marginLeft: 10}}
                />
            </div>

           
 
    </div>

  )
}

export default Menu;


/*
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';

export default function FixedContainer() {
  return (
    <React.Fragment>
      <CssBaseline />
      <Container fixed>
        <Typography component="div" style={{ backgroundColor: '#cfe8fc', height: '100vh',width: -50 }} />
      </Container>
    </React.Fragment>
  );
}
*/
